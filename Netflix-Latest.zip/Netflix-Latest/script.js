document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');

        question.addEventListener('click', () => {
            faqItems.forEach(otherItem => {
                if (otherItem !== item && otherItem.classList.contains('active')) {
                    otherItem.classList.remove('active');
                }
            });

            item.classList.toggle('active');
        });
    });

    const tabButtons = document.querySelectorAll('.tab-btn');

    tabButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            tabButtons.forEach(button => button.classList.remove('active'));
            btn.classList.add('active');
        });
    });

    const forms = document.querySelectorAll('.signup-form');

    forms.forEach(form => {
        form.addEventListener('submit', event => {
            event.preventDefault();

            const emailInput = form.querySelector('input[type="email"]');
            const email = emailInput.value.trim();

            if (validateEmail(email)) {
                alert(`Welcome! You entered: ${email}`);
                return;
            }

            emailInput.style.borderColor = '#e87c03';
            showError(emailInput, 'Please enter a valid email address.');
        });
    });

    const slider = document.querySelector('.trending-slider');
    const modal = document.querySelector('#preview-modal');
    const modalImage = modal.querySelector('.preview-image');
    const modalTitle = modal.querySelector('#preview-title');
    const modalMeta = modal.querySelector('.preview-meta');
    const modalDescription = modal.querySelector('.preview-description');
    const modalCloseButtons = modal.querySelectorAll('[data-modal-close]');
    const modalCta = modal.querySelector('.preview-cta');
    let activePreviewCard = null;

    if (slider) {
        slider.addEventListener('wheel', event => {
            if (Math.abs(event.deltaY) > Math.abs(event.deltaX)) {
                event.preventDefault();
                slider.scrollBy({
                    left: event.deltaY,
                    behavior: 'smooth'
                });
            }
        }, { passive: false });
    }

    const openPreview = card => {
        activePreviewCard = card;
        const image = card.querySelector('img');
        const metaItems = [
            card.dataset.year,
            card.dataset.rating,
            card.dataset.type,
            ...(card.dataset.genres || '').split(',').map(item => item.trim()).filter(Boolean)
        ];

        modalImage.src = image.src;
        modalImage.alt = image.alt;
        modalTitle.textContent = card.dataset.title || image.alt;
        modalDescription.textContent = card.dataset.description || '';
        modalMeta.innerHTML = metaItems.map(item => `<span>${item}</span>`).join('');

        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('modal-open');
        modal.querySelector('.preview-close').focus();
    };

    const closePreview = () => {
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('modal-open');

        if (activePreviewCard) {
            activePreviewCard.focus();
        }
    };

    document.querySelectorAll('.trending-card').forEach(card => {
        card.addEventListener('click', () => openPreview(card));
        card.addEventListener('keydown', event => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                openPreview(card);
            }
        });
    });

    modalCloseButtons.forEach(button => {
        button.addEventListener('click', closePreview);
    });

    modalCta.addEventListener('click', () => {
        closePreview();
        document.querySelector('#hero-email').focus();
    });

    document.addEventListener('keydown', event => {
        if (event.key === 'Escape' && modal.classList.contains('is-open')) {
            closePreview();
        }
    });

    const navbar = document.querySelector('.navbar');
    const updateNavbar = () => {
        navbar.classList.toggle('scrolled', window.scrollY > 40);
    };

    updateNavbar();
    window.addEventListener('scroll', updateNavbar, { passive: true });

    const revealTargets = document.querySelectorAll('.trending-section, .reasons-section, .faq-section, .footer');

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.14 });

        revealTargets.forEach(target => {
            target.classList.add('reveal');
            observer.observe(target);
        });
    } else {
        revealTargets.forEach(target => target.classList.add('is-visible'));
    }
});

function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

function showError(input, message) {
    const existingError = input.parentElement.querySelector('.error-message');
    if (existingError) {
        existingError.remove();
    }

    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.cssText = `
        color: #e87c03;
        font-size: 13px;
        padding: 6px 3px;
        text-align: left;
    `;
    errorDiv.textContent = message;
    input.parentElement.appendChild(errorDiv);

    input.addEventListener('focus', () => {
        input.style.borderColor = '';
        const error = input.parentElement.querySelector('.error-message');
        if (error) {
            error.remove();
        }
    }, { once: true });
}

document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(event) {
        const selector = this.getAttribute('href');

        if (selector === '#') {
            return;
        }

        const target = document.querySelector(selector);

        if (target) {
            event.preventDefault();
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});
